# Computer Vision 
# HW 5
# 11-11-20
# Referenced lecture notes and provided examples

# General Imports
import cv2
import numpy as np
import os

# Adjust these as needed depending on image set
FINAL_IMAGE_WIDTH = 3000
FINAL_IMAGE_HEIGHT = 1000
MIN_MATCHES_NEEDED = 20

# Dir of photos to stitch together
QUARY_DIR = "personal_images"

# Create a resizable window
def create_named_window(window_name, image):
    cv2.namedWindow(window_name, cv2.WINDOW_NORMAL)
    h = image.shape[0]
    w = image.shape[1]

    WIN_MAX_SIZE = 1500
    if max(w,h) > WIN_MAX_SIZE:
        scale = WIN_MAX_SIZE / max(w,h)
    else:
        scale = 1
    cv2.resizeWindow(winname = window_name, width = int(w * scale), height = int(h * scale))


# Calculate the homography transform from one frame to another
# Retruns: Homography matrix
def calc_homography_transformation(mathces_in_subset, kp_train, kp_query):
    if len(mathces_in_subset) < MIN_MATCHES_NEEDED:
        return None, None
    src_pts = np.float32([kp_train[m.trainIdx].pt for m in mathces_in_subset]).reshape(
        -1,1,2
    )
    dest_pts = np.float32([kp_query[m.queryIdx].pt for m in mathces_in_subset]).reshape(
        -1,1,2
    )

    H, _ = cv2.findHomography(srcPoints=src_pts, dstPoints=dest_pts, method=cv2.RANSAC, ransacReprojThreshold=5.0)

    return H

# Use ORB to detect features across time from frame to frame
def detect_features(image, show_features=False):
    detector = cv2.ORB_create(nfeatures=3500)
    gray_scale = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    keypoints, descriptors = detector.detectAndCompute(gray_scale, mask=None)

    return keypoints, descriptors

# Find the Homography from the first frame to the final mosaic, all others are based on this initial 
# homography
def findBaseHomography():
    color_image1 = cv2.imread("{}/image01.JPG".format(QUARY_DIR))
    # For Mosaic
    # source_points = np.array([[153,118],[383,68], [23,480], [308,504]])
    # ortho_points = np.array([[50,50], [369,50], [50, 486], [369,486]])
    source_points = np.array([[2145,803],[3883,616], [2074,2844], [3955,2871]])
    ortho_points = np.array([[350,50], [669,50], [350, 486], [669,486]])
    display_image = color_image1.copy()
    for x,y in source_points:
        cv2.drawMarker(img= display_image, position=(x,y), color= (255,0,0), markerType=cv2.MARKER_DIAMOND,
                        thickness=3)
    H1, _ = cv2.findHomography(srcPoints=source_points, dstPoints=ortho_points)
    print(H1)

    return H1, color_image1

# Stitch the images together using averaging technique with masks
# Returns: combination of two images
def fuse_color_images(A,B):
    assert(A.ndim == 3 and B.ndim == 3)
    assert(A.shape == B.shape)

    C = np.zeros(A.shape, dtype=np.uint8)

    A_mask = np.sum(A, axis=2) >0
    B_mask = np.sum(B,axis=2) > 0

    A_only = A_mask & ~B_mask
    B_only = B_mask & ~A_mask
    A_and_B = A_mask & B_mask

    C[A_only] = A[A_only]
    C[B_only] = B[B_only]
    C[A_and_B] = 0.5 * A[A_and_B] + 0.5 * B[A_and_B]

    return C

def main():
    # Array for storing the individual warped images
    warped_images = []
    # Find initail homography
    homography_previous_2_mosaic, start_image = findBaseHomography()
    # Warp to mosaic
    start_warpped_image = cv2.warpPerspective(start_image, homography_previous_2_mosaic, (FINAL_IMAGE_WIDTH,FINAL_IMAGE_HEIGHT))
    warped_images.append(start_warpped_image)

    # Inital image if name01
    prior = "01".zfill(2)
    # Set me for how many images in folder
    for i in range(2, 11):
        # Get prior and current image
        file_name = str(i).zfill(2)
        prior_image = cv2.imread("{}/image{}.JPG".format(QUARY_DIR, prior))
        current_image = cv2.imread("{}/image{}.JPG".format(QUARY_DIR, file_name))

        # Find objects in each image ORB
        kp_train, desc_train = detect_features(current_image, show_features=False)
        kp_query, desc_query = detect_features(prior_image, show_features=False)

        # Match across images
        match = cv2.BFMatcher.create(cv2.NORM_L2)
        matches = match.knnMatch(desc_query, desc_train, k = 2)

        # Filter for inliers in matching points
        valid = []
        for m,n in matches:
            if m.distance < 0.8 * n.distance:
                valid.append(m)

        # Calculate transform from one image to prior
        homography_current_2_previous = calc_homography_transformation(valid, kp_train, kp_query)
        
        # To mosaic
        homography_current_2_mosaic = np.dot( homography_previous_2_mosaic, homography_current_2_previous)
        image_mosaic = cv2.warpPerspective(current_image, homography_current_2_mosaic, (FINAL_IMAGE_WIDTH, FINAL_IMAGE_HEIGHT))
        warped_images.append(image_mosaic)
        print("Prior {} Current {}".format(prior, file_name))
    
        # Update prior variables
        homography_previous_2_mosaic = homography_current_2_mosaic
        prior = file_name

        # Debugging 
        # create_named_window("Image Mosaic {}".format(file_name), image_mosaic)
        # cv2.imshow("Image Mosaic {}".format(file_name), image_mosaic)
        # cv2.waitKey(0)

    # Construct final image
    final_output_image = np.zeros((FINAL_IMAGE_HEIGHT, FINAL_IMAGE_WIDTH, 3), dtype=np.uint8)
    for image_mosaic in warped_images:
        # Stich
        final_output_image = fuse_color_images(final_output_image, image_mosaic)
        cv2.imshow("M", image_mosaic)
        cv2.imshow("TMP", final_output_image)
        cv2.waitKey(0)

    create_named_window("Final Image", final_output_image)
    cv2.imshow("Final Image", final_output_image)

   
    cv2.waitKey(0)
    # Save final output set name based on image set
    cv2.imwrite("Final_personal.jpg", final_output_image)


if __name__ == "__main__":
    main()